#include "set.h"
#include "set.cpp"
#include <iostream>

using namespace std;

int main() {
    Set<int> s1;
    Set<string> s2;
    int *intArr = new int;
    string *strArr = new string;
    
    s1.add(4);
    s1.add(14);
    s1.add(25);
    s1.add(20);
    s1.add(14);

    intArr = s1.getArray();

    cout << "Set1 has " << s1.getSize() << " items. Here they are: " << endl;
    for (int i = 0; i < s1.getSize(); i++)
        cout << intArr[i] << endl;

    if (intArr != NULL)
    delete[] intArr;

    s2.add("SALAM");
    s2.add("BREED");
    s2.add("POPCORN");
    s2.add("KEBAB");
    s2.add("POPCORN");

    strArr = s2.getArray();

    cout << "Set2 has " << s2.getSize() << " items. Here they are: " << endl;
    for (int i = 0; i < s2.getSize(); i++)
        cout << strArr[i] << endl;

    if (strArr != NULL)
    delete[] strArr;    

    return 0;
}

