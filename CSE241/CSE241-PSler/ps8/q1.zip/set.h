#ifndef SET_H
#define SET_H

#include <iostream>
#include <vector>
using namespace std;

template <class T>
class Set{
    private:
        vector<T> data;
    public:
        Set();
        void add(T item);
        int getSize();
        T* getArray();
};

#endif 