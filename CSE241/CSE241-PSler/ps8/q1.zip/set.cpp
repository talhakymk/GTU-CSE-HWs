#include "set.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

template <class T>
Set<T>::Set(){
    
}

template <class T>
void Set<T>::add(T item){
    bool found = false;
    int i ;
    for(i = 0; (i < data.size() && (found == false)) ; i++){
        if(data[i] == item){
            found = true;
        }
    }
    if(!found){
        data.push_back(item);
    }
    
}

template <class T>
int Set<T>::getSize(){
    return data.size();
}

template <class T>
T* Set<T>::getArray(){
    T* dataArray = new T[data.size()];
    int i;
    for(i = 0 ; i < data.size() ; i++){
        dataArray[i] = data[i];
    }
    return dataArray;
}





