#include <iostream>
#include <string>
using namespace std;

template<class T , class V>
class Pair{
    public:
        Pair(){ };
        Pair(T firstValue, V secondValue);
        void setFirst(T newValue);
        void setSecond(V newValue);
        T getFirst();
        V getSecond();
    private:
        T first;
        V second;
};

template<class T, class V>
Pair<T,V>::Pair(T firstValue , V secondValue){
    this->first = firstValue;
    this->second = secondValue;
}

template<class T , class V>
void Pair<T,V>::setFirst(T newValue){
    this->first = newValue;
}

template<class T , class V>
T Pair<T,V>::getFirst(){
    return first;
}

template<class T , class V>
void Pair<T,V>::setSecond(V newValue){
    this->second = newValue;
}

template<class T , class V>
V Pair<T,V>::getSecond(){
    return second;
}

int main(){
    Pair<char , char> p('T' , 'S');
    cout << "First is " << p.getFirst() << endl;
    p.setFirst('Z');
    cout << "First changed to " << p.getFirst() << endl;
    cout << "The Pair is " << p.getFirst() << " , " << p.getSecond() << endl;

    Pair<int , string> p2(34 , "talha");
    Pair<string , int> p3("turkey" , 81);
    cout << "The pair of p2 is: " << p2.getFirst() << " , " << p2.getSecond() << endl;
    cout << "The pair of p3 is: " << p3.getFirst() << " , " << p3.getSecond() << endl;

    return 0;
}
