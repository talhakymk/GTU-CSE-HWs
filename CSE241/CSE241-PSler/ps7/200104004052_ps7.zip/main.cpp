#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <time.h>
using namespace std;

const int WORLDSIZE = 20;
const int INITIALANTS = 100;
const int INITIALBUGS = 5;
const int DOODLEBUG = 1;
const int ANT = 2;
const int ANTBREED = 3;
const int DOODLEBREED = 8;
const int DOODLESTARVE = 3;

class Organism;
class Ant;
class Doodlebug;

class World {
    friend class Organism;
    friend class Ant;
    friend class Doodlebug;

    private:
        Organism *grid[WORLDSIZE][WORLDSIZE];
    
    public:
        World();

        void Display();
        void SimulateOneStep();

        Organism * getAt(int, int);
        void setAt(int, int, Organism *);

        ~World();

};

class Organism {
    friend class World;

    public:
        Organism();
        Organism(World *, int, int);

        virtual void breed() = 0;
        virtual void move() = 0;
        virtual bool starve() = 0;
        virtual int getType() = 0;

        ~Organism();
    protected:
        int x = 0;
        int y = 0;
        bool moved = false;
        int breedTicks = 0;
        World *world = NULL;
};

class Ant : public Organism {
    friend class World;

    public:
        Ant();
        Ant(World *, int, int);

        void breed();
        void move();
        bool starve();
        int getType();
};

World::World() {
    for (int i = 0; i < WORLDSIZE; i++)
        for (int j = 0; j < WORLDSIZE; j++)
            grid[i][j] = NULL;
}

void World::Display() {
    cout << endl << endl;
    for (int j = 0; j < WORLDSIZE; j++) {
        for (int i = 0; i < WORLDSIZE; i++) {
            if (grid[i][j] == NULL)
                cout << ".";
            else if (grid[i][j]->getType() == ANT)
                cout << "o";
            else
                cout << "X";
        }
        cout << endl;
    }
}

void World::SimulateOneStep() {
    for (int i = 0; i < WORLDSIZE; i++)
        for (int j = 0; j < WORLDSIZE; j++)
            if (grid[i][j] != NULL)
                grid[i][j]->moved = false;
    for (int i = 0; i < WORLDSIZE; i++) {
        for (int j = 0; j < WORLDSIZE; j++) {
            if (grid[i][j] != NULL && grid[i][j]->getType() == DOODLEBUG) {
                if (!grid[i][j]->moved) {
                    grid[i][j]->moved = true;
                    grid[i][j]->move();
                }
            }
        }
    }
    for (int i = 0; i < WORLDSIZE; i++) {
        for (int j = 0; j < WORLDSIZE; j++) {
            if (grid[i][j] != NULL && grid[i][j]->getType() == ANT) {
                if (!grid[i][j]->moved) {
                    grid[i][j]->moved = true;
                    grid[i][j]->move();
                }
            }
        }
    }
    for (int i = 0; i < WORLDSIZE;i++) {
        for (int j = 0; j < WORLDSIZE; j++) {
            if (grid[i][j] != NULL && grid[i][j]->getType() == DOODLEBUG) {
                if (grid[i][j]->starve()) {
                    delete grid[i][j];
                    grid[i][j] = NULL;
                }
            }
        }
    }
    for (int i = 0; i < WORLDSIZE;i++)
        for (int j = 0; j < WORLDSIZE; j++)
            if (grid[i][j] != NULL && grid[i][j]->moved)
                grid[i][j]->breed();
}

Organism * World::getAt(int x, int y) {
    if (x >= 0 && x < WORLDSIZE && y >= 0 && y < WORLDSIZE)
        return grid[x][y];
    return NULL;
}

void World::setAt(int x, int y, Organism *org) {
    if (x >= 0 && x < WORLDSIZE && y >= 0 && y < WORLDSIZE)
        grid[x][y] = org;
}

World::~World() {
    for (int i = 0; i < WORLDSIZE; i++)
        for (int j = 0; j < WORLDSIZE; j++)
            if (grid[i][j] != NULL)
                delete grid[i][j];
}

Organism::Organism() { }

Organism::Organism(World *_world, int x, int y) {
    this->world = _world;
    this->x = x;
    this->y = y;
    _world->setAt(x, y, this);
}

Organism::~Organism() { }

Ant::Ant() : Organism() { }

Ant::Ant(World *world, int x, int y) : Organism(world, x, y) { }

void Ant::breed() {
    ++breedTicks;
    if (breedTicks == ANTBREED) {
        breedTicks = 0;
        if (y > 0 && world->getAt(x,y-1) == NULL)
            Ant *newAnt = new Ant(world, x, y-1);
        else if (y < WORLDSIZE-1 && world->getAt(x,y+1) == NULL)
            Ant *newAnt = new Ant(world, x, y+1);
        else if (x > 0 && world->getAt(x-1,y) == NULL)
            Ant *newAnt = new Ant(world, x-1, y);
        else if (x < WORLDSIZE-1 && world->getAt(x+1,y) == NULL)
            Ant *newAnt = new Ant(world, x+1, y);
    }
}

void Ant::move() {
    int dir = rand() % 4;
    if (dir == 0) {
        if (y > 0 && world->getAt(x,y-1) == NULL) {
            world->setAt(x, y-1, world->getAt(x,y));
            world->setAt(x, y-1, this);
            world->setAt(x, y, NULL);
            --y;
        }
    } else if (dir == 1) {
        if (y < WORLDSIZE-1 && world->getAt(x,y+1) == NULL) {
            world->setAt(x, y+1, world->getAt(x,y));
            world->setAt(x, y, NULL);
            ++y;
        }
    } else if (dir == 2) {
        if (x > 0 && world->getAt(x-1, y) == NULL) {
            world->setAt(x-1, y, world->getAt(x,y));
            world->setAt(x, y, NULL);
            ++x;
        }
    }
}

bool Ant::starve() { return false; }

int Ant::getType() { return ANT; }

class Doodlebug : public Organism {
    friend class World;

    private:
        int starveTicks = 0;
    public:
        Doodlebug();
        Doodlebug(World *, int, int);

        void breed();
        void move();
        bool starve();
        int getType();
};

Doodlebug::Doodlebug() : Organism() { }

Doodlebug::Doodlebug(World *world, int x, int y) : Organism(world, x, y) { }

void Doodlebug::breed() {
    ++breedTicks;
    if (breedTicks == DOODLEBREED) {
        breedTicks = 0;
        if (y > 0 && world->getAt(x,y-1) == NULL)
            Doodlebug *newDoodle = new Doodlebug(world, x, y-1);
        else if (y < WORLDSIZE-1 && world->getAt(x,y+1) == NULL)
            Doodlebug *newDoodle = new Doodlebug(world, x, y+1);
        else if (x > 0 && world->getAt(x-1,y) == NULL)
            Doodlebug *newDoodle = new Doodlebug(world, x-1, y);
        else if (x < WORLDSIZE-1 && world->getAt(x+1,y) == NULL)
            Doodlebug *newDoodle = new Doodlebug(world, x+1, y);
    }
}

void Doodlebug::move() {
    if (y > 0 && world->getAt(x,y-1) != NULL && world->getAt(x,y-1)->getType() == ANT) {
        delete world->grid[x][y-1];
        world->grid[x][y-1] = this;
        world->setAt(x, y, NULL);
        starveTicks = 0;
        --y;
        return;
    } else if (y < WORLDSIZE-1 && world->getAt(x,y+1) != NULL && world->getAt(x,y+1)->getType() == ANT) {
        delete world->grid[x][y+1];
        world->grid[x][y+1] = this;
        world->setAt(x, y, NULL);
        starveTicks = 0;
        ++y;
        return;
    } else if (x > 0 && world->getAt(x-1,y) != NULL && world->getAt(x-1,y)->getType() == ANT) {
        delete world->grid[x-1][y];
        world->grid[x-1][y] = this;
        world->setAt(x, y, NULL);
        starveTicks = 0;
        --x;
        return;
    } else if (x < WORLDSIZE-1 && world->getAt(x+1,y) != NULL && world->getAt(x+1,y)->getType() == ANT) {
        delete world->grid[x+1][y];
        world->grid[x+1][y] = this;
        world->setAt(x, y, NULL);
        starveTicks = 0;
        ++x;
        return;
    }
}

bool Doodlebug::starve() { return starveTicks > DOODLESTARVE; }

int Doodlebug::getType() { return DOODLEBUG; }

int main() {
    string s;
    srand(time(NULL));
    World w;

    int antCount = 0;
    while (antCount < INITIALANTS) {
        int x = rand() % WORLDSIZE;
        int y = rand() % WORLDSIZE;
        if (w.getAt(x,y) == NULL) {
            ++antCount;
            Ant *a1 = new Ant(&w, x, y);
        }
    }

    int doodleCount = 0;
    while (doodleCount < INITIALBUGS) {
        int x = rand() % WORLDSIZE;
        int y = rand() % WORLDSIZE;
        if (w.getAt(x,y) == NULL) {
            ++doodleCount;
            Doodlebug *d1 = new Doodlebug(&w, x, y);
        }
    }

    while (true) {
        w.Display();
        w.SimulateOneStep();
        cout << endl << "Press enter for next step" << endl;
        getline(cin,s);
    }
    return 0;
}