#include <iostream>
using namespace std;

class Vector2D{
    private:
        int x,y;
    public:
        void SetX(int x){
            this->x = x;
        }
        int GetX(){
            return x;
        }
        void SetY(int y){
            this->y = y;
        }
        int GetY(){
            return y;
        }
        Vector2D(){
            SetX(0);
            SetY(0);
        }
        Vector2D(int x , int y){
            SetX(x);
            SetY(y);
        }
        Vector2D(int x){
            SetX(x);
            SetY(0);
        }
         int operator* (Vector2D value);

        
};
    int  Vector2D::operator*(Vector2D value){
        return (this->x * value.x) + (this->y * value.y);
    }

int main(){
    Vector2D v1(4,7) , v2(2,10) , v3(8,1) , v4(5,4) ;
    cout << "(" << v1.GetX() << "," << v1.GetY() << ") * (" << v2.GetX() 
        << "," << v2.GetY() << ") = " << v1*v2 << endl; 
    cout << "(" << v2.GetX() << "," << v2.GetY() << ") * (" << v3.GetX() 
        << "," << v3.GetY() << ") = " << v2*v3 << endl; 
    cout << "(" << v3.GetX() << "," << v3.GetY() << ") * (" << v4.GetX() 
        << "," << v4.GetY() << ") = " << v3*v4 << endl; 
    
    return 0;
}