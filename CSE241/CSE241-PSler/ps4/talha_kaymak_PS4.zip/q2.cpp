#include <iostream>
#include <cmath>
using namespace std;

class MyInteger{
    private:
        int number;
    public:
        void setNumber(int number){
            this->number = number;
        }
        int getNumber(){
            return number;
        }
        MyInteger(){
            setNumber(0);
        }
        MyInteger(int number){
            setNumber(number);
        }
         int operator[](int digit);

};

int MyInteger::operator[](int digit){
    int a = 0;
    int numofdigit = this->getNumber();
    int result = this->getNumber();
    while(numofdigit > 0)
    {
        numofdigit = numofdigit / 10;
        a++;
    }
    if(digit + 1 > a || digit < 0){
        return -1;
    }
    for(int i = 0 ; i < digit ; i++){
        result = result / 10;
    }
    result = result % 10;
    return result;
}

int main(){
    MyInteger num(459);
    cout << num[0] << " " << num[1] << " " << num[2] << endl;
    cout << num[3] << endl;
    cout << num[-1] << endl;
    return 0;
}