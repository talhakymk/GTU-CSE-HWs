#include <iostream>
using namespace std;

class Student{

    private:
        string name;
        int numClasses;
        string* classList = new string[5];
    public:
        string getName(){return name; }
        int getNumClasses(){return numClasses;}
        void setName(string name){ this->name = name; }
        void setNumClasses(int num){ this->numClasses = num;}
        void InputData();
        void OutputData();
        void Reset();
        Student(){ };
        Student operator=(Student obj);
};
    Student Student::operator=(Student obj){
        this->name = obj.name;
        this->numClasses = obj.numClasses;
        for(int i = 0 ; i < getNumClasses() ; i++){
            this->classList[i] = obj.classList[i];
        }
        return *this;
    }
    void Student::InputData(){
        string name;
        int number;
        string* list = NULL;
        cout << "Enter name of student : ";
        cin >> name;
        cout << "Enter number of classes : ";
        cin >> number;
        list = new string[number];
        cout << "Enter name of classes : ";
        setName(name);
        setNumClasses(number);
        for(int i = 0 ; i < number ; i++){
            cin >> classList[i];
        }
    }

    void Student::OutputData(){
        cout << "Name : " << getName() << endl;
        cout << "Num Of Classes : " << getNumClasses() << endl;
        cout << "Classes : " << endl;
        for(int i = 0; i < getNumClasses() ; i++){
            cout << classList[i] << endl;
        }
        cout << endl;
    }

    void Student::Reset(){
        setNumClasses(0);
        classList = NULL;
    }


int main(){
    Student s1 , s2;
    s1.InputData();
    cout << "Student 1's data:" << endl;
    s1.OutputData();
    cout << endl;
   /* s2.InputData();
    cout << endl;
    cout << "Student 2's data: " << endl;
    s2.OutputData();*/
    s2 = s1;
    cout << "Student 2's data is equal to students 1 data now " << endl;
    s2.OutputData();
    cout << endl;
    s1.Reset();
    cout << "Student 1's data after reset:" << endl;
    s1.OutputData();
    cout << endl;
    cout << "Student 2's data, should still have students1 data" << endl;
    s2.OutputData();
    cout << endl;

    return 0;
}