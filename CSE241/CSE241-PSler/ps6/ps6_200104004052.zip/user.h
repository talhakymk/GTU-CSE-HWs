
#include <string>
#include <iostream>

namespace {
    bool isValid();
 
    
   std::string username;
}

namespace Authenticate
{
    void inputUserName();
    std::string getUserName();
}