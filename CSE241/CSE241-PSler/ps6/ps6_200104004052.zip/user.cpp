#include "user.h"

namespace Authenticate

{


void inputUserName()
{
do
{
std::cout << "Enter your username (8 letters only)" << std::endl;
std::cin >> username;
} while (!isValid());
}
std::string getUserName()
{
return username;
}


}

namespace {

        bool isValid(){
          if(username.length() ==8)  
           return true;
           else
            return false;
        }
}