#include <string>
#include <iostream>

namespace Authenticate{
void inputPassword();
std::string getPassword();

}
 namespace 
{
    std::string password;
    bool isValid();
} 