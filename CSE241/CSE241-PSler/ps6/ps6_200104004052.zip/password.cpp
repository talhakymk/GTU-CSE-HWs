#include "password.h"

namespace Authenticate
{
    void inputPassword()
    {
    do
    {
        std::cout << "Enter your password (at least 8 characters " << "and at least one non-letter)" << std::endl;
        std::cin >> password ;
    } while (!isValid());
        }
            std::string getPassword()
        {
    return password;
    }
}

 namespace 
{
    
    bool isValid(){
        bool atleast = false;
      
        for(int i = 0;i<password.length();i++){
            if(password.at(i) > 122 || password.at(i) < 65 || (password.at(i) < 97 && password.at(i)>90) )
            atleast = true;
        }
        if(atleast == true && password.length()>8)
        return true;
        else
        return false;
    }
} 
