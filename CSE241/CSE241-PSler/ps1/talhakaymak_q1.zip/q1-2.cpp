#include <iostream>
#include <ctime>
using namespace std;

int humanturn(int humantotalscore){
    char choose;
    //srand(time(0));
    while(true){
    cout << "if you want to roll again press r and if you want to hold press h \n";
    cin >> choose;
    if(choose == 'r'){
   // srand(time(0));
    int dice = rand() % 6 + 1;
    cout << "your dice is :" << dice << endl;
    if(dice == 1){
        return 0;
    }
    else{
        humantotalscore += dice;
        
        }
    }
    if(choose == 'h'){
        return humantotalscore;
    }
}

}

int computerturn(int computertotalscore){
    //srand(time(0));
    while(true){
    //srand(time(0));
    int dice = rand() % 6 + 1;
    cout << "computer's dice is :" << dice << endl;
    if(dice == 1){
        return 0;
    }
    else{
        computertotalscore += dice;
        
    }
    if(computertotalscore >= 20){
        return computertotalscore;
    }
    }
}

int main(){
    srand(time(0));
    int humanscore = 0;
    int computerscore = 0;
    cout << "welcome  to pig game \n";
    while(true){
        if(humanscore >= 100){
            cout << "you win";
            return 0;
        }
        if(computerscore >= 100){
            cout << "you loss";
            return 0;
        }
    int a = 0;
    int b = 0;
    humanscore += humanturn(a);
    cout << "your current score is :" << humanscore << endl;
    computerscore += computerturn(b);
    cout << "computers current score is :" << computerscore << endl;
    }
    
    
        




    return 0;
}