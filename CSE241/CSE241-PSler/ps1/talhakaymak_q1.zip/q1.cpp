#include <iostream>
using namespace std;

int main(){

        int sayac1=0,sayac2=0;
	
	for(int i=2;i<=100;i++)  // burada istenilen aralığı veriyoruz
	{
		sayac1=0;
		for(int j=2;j<i;j++) 
		{
			if(i%j==0) // eğerki güncel sayı kendinden başka bi sayıya tam bölünmüyorsa asal oluyor ve buraya girmiyor
			{
				sayac1++;
				break; 
			}
		}
		if(sayac1==0) // sayac1 artmadığı için güncel i değeri asal sayı oluyor
		{
			cout<<i<<" ";
			sayac2++;
		}
	}
	cout<<endl;

    return 0;
}