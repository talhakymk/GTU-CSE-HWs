#include <iostream>
#include <string.h>
using namespace std;

int main(){
    char num1[20];
    char num2[20];
    unsigned int a = 0;
    unsigned int b = 0;
    cout << "please enter first integer :";
    cin >> num1 ;
    if(strlen(num1) > 20){
        cout << "you entered more than 20 digits";
        return 0;
    }
    cout << "please enter second integer :";
    cin >> num2;
    if(strlen(num2) > 20){
        cout << "you entered more than 20 digits";
        return 0;
    }
    a = atoi(num1);
    b = atoi(num2);
    
    unsigned int c = a + b;
    

    int digits = 0; do { c /= 10; digits++; } while (c != 0);

    
    if(digits > 20){
        cout << "integer overflow";
        return 0;
    }
    cout << "summ of these two int is :" << (a + b) << "\n";
    return 0;
}