#include <iostream>
using namespace std;

class HotDogStand{

    private:
        int id;
        int numberofsold;
    public:
        HotDogStand();
        HotDogStand(int ID , int NUMBER);
        void JustSold();
        int getNumberofsold();
        static int getTotalNumberOfHotDog();
        static int TotalNumberOfHotDog;
        

};
    int HotDogStand::TotalNumberOfHotDog = 0 ;

    int HotDogStand::getTotalNumberOfHotDog(){
        return TotalNumberOfHotDog;
    }

    int HotDogStand::getNumberofsold(){
        return numberofsold;
    }

    HotDogStand::HotDogStand(int ID , int NUMBER){
        this->id = ID;
        this->numberofsold = NUMBER;
        TotalNumberOfHotDog += NUMBER;
        
    }

    HotDogStand::HotDogStand(){
        this->id = 0;
        this->numberofsold = 0;
    }
    void HotDogStand::JustSold(){
        cout << "you just sold a hotdog \n";
        this->numberofsold++;
        TotalNumberOfHotDog += 1;
    }

    void output(HotDogStand a1 , HotDogStand a2 , HotDogStand a3){
    cout << "number of sold hotdogs for stand1 is : " << a1.getNumberofsold() << endl;
    cout << "number of sold hotdogs for stand2 is : " << a2.getNumberofsold() << endl;
    cout << "number of sold hotdogs for stand3 is : " << a3.getNumberofsold() << endl;
    cout << "total number of hot dogs for all stands is :" << HotDogStand::getTotalNumberOfHotDog() << endl << endl;

    }

int main(){

    HotDogStand stand1(1 , 20);
    HotDogStand stand2(2 , 25);
    HotDogStand stand3(3 , 14);

    output(stand1 , stand2 , stand3);
        
    stand1.JustSold();
    stand2.JustSold();
    stand3.JustSold();
    cout << endl;

    output(stand1 , stand2 , stand3);

    return 0;
}