#include <iostream>
#include <vector>
using namespace std;

void printSuitors(vector<int> a){
    for(auto i = a.begin() ; i!= a.end() ; i++){
        cout << *i << ' ' ;
    }
}

int main(){
        vector<int> suitors ;
        int numberOfsuitors = 0;
        int sayac = 0;
        cout << "enter number of suitors \n";
        cin >> numberOfsuitors;
        for(int i = 1 ; i <= numberOfsuitors ; i++){
            suitors.push_back(i);
        }
        printSuitors(suitors);
        cout << endl;
        
        while(suitors.size() > 1){
            for (int i = 0; i < 2; i++) {
			sayac++;

			if (sayac == suitors.size()) {
				sayac = 0;
			}
		}
        cout << suitors[sayac] << " is eliminated \n\n";
        suitors.erase(suitors.begin() + sayac);
		
		if (sayac == suitors.size()) {
            sayac = 0;
        }
		
        printSuitors(suitors);
        cout << endl;
	}
    cout << "winner suitor is : " << suitors[0] << endl;

    return 0;
}