#include <stdio.h>

void foo_min_max(int arr[], int n){
	int temp = 0;
	for (int i = 1; i < n; ++i) {
    		if (arr[0] < arr[i]) {
      		temp = arr[0];
      		arr[0] = arr[i];
      		arr[i] = temp;
      		
    }
  }
  for (int i = 1; i < n; ++i) {
    		if (arr[n-1] > arr[i]) {
      		temp = arr[n-1];
      		arr[n-1] = arr[i];
      		arr[i] = temp;
      		
    }
  }

  printf("maximum = %d\n", arr[0]);
  printf("minimum  = %d\n", arr[n-1]);
	
}


int main(){
	int number = 0;
	printf("please enter how many number will you enter : ");
	scanf("%d",&number);
	int integers[number];
	printf("please enter %d integers : \n",number);
	for(int i = 0 ; i < number ; i++){
		scanf("%d",&integers[i]);
	}
	foo_min_max(integers,number);
	return 0;

}
