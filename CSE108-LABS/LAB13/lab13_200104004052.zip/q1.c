#include <stdio.h>
#include <stdlib.h>

struct Node {
    double Value;
    struct Node* LeftNode;
    struct Node* RightNode;
};

struct BST {
    struct Node* root;
};

struct Node* createNode(double value); 
void insertNode(struct Node* currentNode, double value); 
struct BST* generateBST(const char* filename); 
void OrderTree(struct Node* node); 

int main() {
    const char* filename = "input.txt";
    struct BST* bst = generateBST(filename);
    printf("Ordered: ");
    OrderTree(bst->root);
    printf("\n");
    return 0;
}

struct Node* createNode(double value) {
    struct Node* new = (struct Node*)malloc(sizeof(struct Node));
    new->Value = value;
    new->LeftNode = NULL;
    new->RightNode = NULL;
    return new;
}

void insertNode(struct Node* currentNode, double value) {
    if (value < currentNode->Value) {
        if (currentNode->LeftNode == NULL) {
            currentNode->LeftNode = createNode(value);
        }
        else {
            insertNode(currentNode->LeftNode, value);
        }
    }
    else {
        if (currentNode->RightNode == NULL) {
            currentNode->RightNode = createNode(value);
        }
        else {
            insertNode(currentNode->RightNode, value);
        }
    }
}

struct BST* generateBST(const char* filename) {
    struct BST* bst = (struct BST*)malloc(sizeof(struct BST));
    bst->root = NULL;

    FILE* file = fopen(filename, "r");
    double value;
    fscanf(file, "%lf", &value);
    bst->root = createNode(value);

    while (fscanf(file, "%lf", &value) == 1) {
        insertNode(bst->root, value);
    }

    fclose(file);
    return bst;
}

void OrderTree(struct Node* node) {
    if (node == NULL) {
        return;
    }
    OrderTree(node->LeftNode);
    printf("%.2lf ", node->Value);
    OrderTree(node->RightNode);
}



