#include <stdio.h>
#include <string.h>

struct data{
	char name[50];
	char color[50];
	float price;
	int serial_number;
	int quantity;

}data;

void SeeAll(){
	FILE *fp;
	struct data a;
	if ( (fp = fopen("furniture_database.txt","r"))==NULL) {
        printf("Dosya açılamadı");
        return;
    }
    		while(! feof(fp)){
			fscanf(fp , "%s\n" ,a.name);
			fscanf(fp , "%s\n" ,a.color);
			fscanf(fp , "%f\n" ,&a.price);
			fscanf(fp , "%d\n" ,&a.serial_number);
			fscanf(fp , "%d\n" ,&a.quantity);
			printf("Name : %s\n",a.name);
			printf("Color : %s\n",a.color);
			printf("Price : %.2f\n",a.price);
			printf("Serial Number : %d\n",a.serial_number);
			printf("Quantity : %d\n\n",a.quantity);
		}		
}

void AddNew(){
	FILE *fp; 
	struct data b;
	char name[50] , color[50];
	float price = 0;
	int serial_number = 0 , quantity = 0;
	printf("Please enter the properties of new furniture\n");
	scanf("%s",b.name);
	scanf("%s",b.color);
	scanf("%f",&b.price);
	scanf("%d",&b.serial_number);
	scanf("%d",&b.quantity);
	if ( (fp = fopen("furniture_database.txt","a"))==NULL) {
        printf("Dosya açılamadı");
        return;
        }
        fprintf(fp,"%s\n",b.name);
    	fprintf(fp,"%s\n",b.color);
    	fprintf(fp,"%f\n",b.price);
    	fprintf(fp,"%d\n",b.serial_number);
    	fprintf(fp,"%d\n",b.quantity);

    fclose(fp);
	
}

void Search(){
	char namee[50] , colorr[50];
	printf("select how to search\n1-name\n2-color\n");
	int cho = 0;
	scanf("%d",&cho);
	if(cho == 1){
		printf("Enter name of a furniture to search\n");
		scanf("%s",namee);
		FILE *fp;
		struct data a;
		if ( (fp = fopen("furniture_database.txt","r"))==NULL) {
		printf("Dosya açılamadı");
		return;
	    }
	    		while(! feof(fp)){
				fscanf(fp , "%s\n" ,a.name);
				fscanf(fp , "%s\n" ,a.color);
				fscanf(fp , "%f\n" ,&a.price);
				fscanf(fp , "%d\n" ,&a.serial_number);
				fscanf(fp , "%d\n" ,&a.quantity);
				if(strcmp(a.name , namee) == 0){
					printf("Name : %s\n",a.name);
					printf("Color : %s\n",a.color);
					printf("Price : %.2f\n",a.price);
					printf("Serial Number : %d\n",a.serial_number);
					printf("Quantity : %d\n\n",a.quantity);
				}
			}	
	}	
	
	if(cho == 2){
		printf("Enter color of a furniture to search\n");
		scanf("%s",colorr);
		FILE *fp;
		struct data a;
		if ( (fp = fopen("furniture_database.txt","r"))==NULL) {
		printf("Dosya açılamadı");
		return;
	    }
	    		while(! feof(fp)){
				fscanf(fp , "%s\n" ,a.name);
				fscanf(fp , "%s\n" ,a.color);
				fscanf(fp , "%f\n" ,&a.price);
				fscanf(fp , "%d\n" ,&a.serial_number);
				fscanf(fp , "%d\n" ,&a.quantity);
				if(strcmp(a.color , colorr) == 0){
					printf("Name : %s\n",a.name);
					printf("Color : %s\n",a.color);
					printf("Price : %.2f\n",a.price);
					printf("Serial Number : %d\n",a.serial_number);
					printf("Quantity : %d\n\n",a.quantity);
				}
			}	
	}	
	
}

void Remove(){
	int index = 0 , i = 0;
	printf("Enter index for removing\n");
	scanf("%d",&index);
	FILE *fp;
	struct data a;
	if ( (fp = fopen("furniture_database.txt","r"))==NULL) {
        printf("Dosya açılamadı");
        return;
    }
    		while(! feof(fp)){
    		int j = 0;
				fscanf(fp , "%s\n" ,a.name);
				fscanf(fp , "%s\n" ,a.color);
				fscanf(fp , "%f\n" ,&a.price);
				fscanf(fp , "%d\n" ,&a.serial_number);
				fscanf(fp , "%d\n" ,&a.quantity);
			if(index == i){
				continue;
			}
			else{
				FILE *fp2; 
				if ( (fp2 = fopen("temp.txt","a"))==NULL) {
				printf("Dosya açılamadı");
				return;
				}
				fprintf(fp2,"%s\n",a.name);
			    	fprintf(fp2,"%s\n",a.color);
			    	fprintf(fp2,"%f\n",a.price);
			    	fprintf(fp2,"%d\n",a.serial_number);
			    	fprintf(fp2,"%d\n",a.quantity);
											
			}
			i++;
		}
		fclose(fp);
		

}


int main(){
	int i = 1;
	int choice = 0;
	while(i = 1){
		printf("***************\n");
		printf("Welcome to database of furniture shop\n");
		printf("1-See all furnitures\n");
		printf("2-Add a new furniture\n");
		printf("3-Remove furniture\n");
		printf("4-Search furniture\n");
		printf("5-Exit\n");
		scanf("%d",&choice);
		if(choice == 1){
			SeeAll();
		}
		if(choice == 2){
			AddNew();
		}
		if(choice == 3){
			Remove(); // çalışmıyot
		}
		if(choice == 4){
			Search();
		}
		if(choice == 5){
			return 0;
		}
	}
	


	return 0;
}
