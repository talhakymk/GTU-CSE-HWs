#include <stdio.h>
#include <math.h>

#define PI  3.14159265

typedef struct vector
{
	float x;
	float y;
	float z;
} vector;

double find_orthogonal(struct vector v1 ,struct vector v2 ,struct vector *output){
	float Aleng = 0 , Bleng = 0 , dotPro = 0;
	double angle = 0 , finito = 0 , val = 0;
	Aleng = (((v1.x) * (v1.x)) + ((v1.y) * (v1.y)) + ((v1.z) * (v1.z)));
	Aleng = sqrt(Aleng);
	Bleng = (((v2.x) * (v2.x)) + ((v2.y) * (v2.y)) + ((v2.z) * (v2.z)));
	Bleng = sqrt(Bleng);
	dotPro = (v1.x * v2.x) + (v1.y * v2.y) + (v1.z * v2.z);
	finito = (dotPro / (Aleng * Bleng));
	val = (180.0 / PI);
	angle = acos(finito) * val;
	output->x = (v1.y * v2.z) - (v1.z * v2.y);
	output->y = (v1.z * v2.x) - (v1.x * v2.z);
	output->z = (v1.x * v2.y) - (v1.y * v2.x);
	return angle;
}



int main(){
	struct vector v1;
	struct vector v2; 
	struct vector output;
	printf("Please enter coordinates of first vector \n");
	scanf("%f",&v1.x);
	scanf("%f",&v1.y);
	scanf("%f",&v1.z);
	printf("Please enter coordinates of second vector \n");
	scanf("%f",&v2.x);
	scanf("%f",&v2.y);
	scanf("%f",&v2.z);
	printf("%f\n",find_orthogonal(v1 , v2 , &output));
	printf("x coordinates of cross product is : %.2f\n",output.x);
	printf("y coordinates of cross product is : %.2f\n",output.y);
	printf("z coordinates of cross product is : %.2f\n",output.z);
	
	return 0;
}
