#include <stdio.h>

typedef struct matrix
{
	float arr[3][3];
	float det;

} matrix;

void print_matrix(struct matrix m1){
	for(int i = 0; i < 3 ; i++){
		for(int j = 0; j < 3 ; j++){
			printf("%.4f ",m1.arr[i][j]);
		}
		printf("\n");
	}

}


int main(){
	struct matrix m1;
	printf("fold the matrix \n");
	for(int i = 0; i < 3 ; i++){
		for(int j = 0; j < 3 ; j++){
			scanf("%f",&m1.arr[i][j]);
		}
	}
	print_matrix(m1);
	


	return 0;
}
