#include <stdio.h>
#include <stdlib.h>

int* return_Array(int size){
	int* ptr;
	int min = 0;
	ptr = (int*)malloc(size * sizeof(int));
	if (ptr == NULL) {
        	printf("Memory not allocated.\n");
    	} 
    	else{
    		printf("enter integers for array\n");
    		for (int j = 0; j < size; ++j) {
            		scanf("%d",&ptr[j]);
        	}
        	min = ptr[0];
        	for (int j = 0; j < size; ++j) {
  
            		if(min < ptr[j]){
            			min = min;
            		}
            		else{
            			min = ptr[j];
            		}
            		
        	}
    	}
	return ptr;

}


int main(){
	int size = 0;
	int min = 0;
	int* ptr2;
	printf("Enter the size of an array\n");
	scanf("%d",&size);
	ptr2 = (int*)calloc(size , sizeof(int));
	ptr2 = return_Array(size);
	printf("First array : ");
	for(int i = 0 ; i < size ; i++){
		printf("%d ",ptr2[i]);
	}
	printf("\n");
	printf("Second array(cumulative sum) : ");
	printf("%d ",ptr2[0]);
	for (int i=1; i<size; i++) {
       	ptr2[i] = ptr2[i] + ptr2[i-1]; 
       	printf("%d ", ptr2[i]); 
   	}
	printf("\n");
	return 0;
}
