#include <stdio.h> 
#include <stdlib.h>
#include <time.h>

struct Student{
	int ID;
	int Age;
	float Gpa;
};

float calculateAvGpa(struct Student *Allstudent){
	float total = 0.0;
	for(int j = 0 ; j < 10000 ; j++){
		total += Allstudent[j].Gpa;
	}
	
	return (total/10000);

}

void createRandomStd(struct Student *student){
	srand(time(NULL));
	for(int i = 0 ; i < 10000 ; i++){
		student[i].ID = i+1;
		student[i].Age = rand() % 12 + 18;
		student[i].Gpa = (float)(rand() % 90) / 10;
	
	}

}

int main(){
	srand(time(NULL));
	float totalAvg = 0.0;
	for(int i = 0 ; i < 10000 ; i++){
		struct Student *std = (struct Student*)malloc(10000 * sizeof(struct Student));
		createRandomStd(std);
		totalAvg += calculateAvGpa(std);
		free(std);
	}
	float average = (totalAvg / 10000);
	printf("Average GPA of 10.000 x 10.000 students : %.2f \n",average);
	
	return 0;
}
