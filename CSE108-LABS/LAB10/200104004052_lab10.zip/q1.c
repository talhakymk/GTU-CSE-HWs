#include <stdio.h>
#include <stdlib.h>

int return_Min(int size){
	int* ptr;
	int min = 0;
	ptr = (int*)malloc(size * sizeof(int));
	if (ptr == NULL) {
        	printf("Memory not allocated.\n");
    	} 
    	else{
    		printf("enter integers for array\n");
    		for (int j = 0; j < size; ++j) {
            		scanf("%d",&ptr[j]);
        	}
        	min = ptr[0];
        	for (int j = 0; j < size; ++j) {
  
            		if(min < ptr[j]){
            			min = min;
            		}
            		else{
            			min = ptr[j];
            		}
            		
        	}
    	}
	return min;

}


int main(){
	int size = 0;
	int min = 0;
	printf("Enter the size of an array\n");
	scanf("%d",&size);
	min = return_Min(size);
	printf("Min of the array elements : %d \n",min);
	return 0;
}
