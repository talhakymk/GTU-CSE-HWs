#include <stdio.h>
int size = 0;
int ReadInputs(int arr[]){
	int a = 0 , i = 0;
	while(a !=-100){
		scanf("%d",&a);
		if(a ==-100){
			return 0;
		}
		arr[i] = a;
		i++;
		size++;
	}
	return 0;

}

void PrintfResult(int arr[] , char array[] , int size){
	for(int i = 0; i < size ; i++){
		printf("%d %c \n",arr[i],array[i]);
	}
}

int main(){
	int arr[100];
	printf("Please enter list of integers\n");
	ReadInputs(arr);
	char array[size];
	for(int i = 0; i < size ; i++){
		if(arr[i] % 2 == 0){
			array[i] = 'e';
		}
		else{
			array[i] = 'o';
		}
	}
	PrintfResult(arr , array , size);
	
	
	
	
	return 0;
}
