#include <stdio.h>

void CalculateSalary(char team[] , float salary[] , int row){
	char select;
	float total = 0.0;
	int a = 0;
	printf("Please  select a team : ");
	scanf(" %c",&select);
	for(int i = 0 ; i < row ; i++){
		if(team[i] == select){
			total += salary[i];
			a++;
		}
		if(i == (row - 1) && a == 0){
			printf("There are no fans of %c in the database!\n" , select);
			return;
		}
	}
	printf("Average salaries of fans of %c : ",select);
	float avg = (total / a);
	printf("%.2f\n",avg);
}

int main(){
	int row = 0;
	FILE *dosya = fopen("table.txt", "r");
	fscanf(dosya, "%d\n" ,&row);
	int age[row];
	char occu[row];
	float salary[row];
	char team[row];
	
	for(int i = 0; i < row; i++){
		fscanf(dosya , "%d\t" ,&age[i]);
		fscanf(dosya , "%c\t" ,&occu[i]);
		fscanf(dosya , "%f\t" ,&salary[i]);
		fscanf(dosya , "%c\t" ,&team[i]);
	}
	fclose(dosya);
	CalculateSalary(team , salary , row);

	return 0;
}
