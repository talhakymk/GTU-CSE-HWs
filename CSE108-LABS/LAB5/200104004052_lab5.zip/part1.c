#include <stdio.h>

void ConvertCtoF(){
	float temper = 0 , result = 0;
	printf("Enter the temperature value to convert : ");
	scanf("%f",&temper);
	result = ((temper * 9 / 5) + 32);
	printf("%.2f Celsius = %.2f Fahrenheit \n\n",temper,result);
}

void ConvertFtoC(){
	float temper = 0 , result = 0;
	printf("Enter the temperature value to convert : ");
	scanf("%f",&temper);
	result = ((temper - 32) * 5 / 9);
	printf("%.2f Celsius = %.2f Fahrenheit \n\n",temper,result);
}

int main(){
	int i = 0 , choice = 0;
	while(i == 0){
		printf("Temperature Conversion Menu\n");
		printf("1. Convert Celsius to Fahrenheit\n");
		printf("2. Convert Fahrenheit to Celsius\n");
		printf("3. Quit\n");
		printf("Enter your choice (1-3) : ");
		scanf("%d",&choice);
		if(choice == 1){
			ConvertCtoF();
		}
		else if(choice == 2){
			ConvertFtoC();
		}
		else if(choice == 3){
			return 0;
		}
		else{
			printf("Wrong Input\n");
		}
	}
	
	return 0;
}
