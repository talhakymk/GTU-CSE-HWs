#include <stdio.h>

int main(){
	int number = 0 , digit = 0 , reversed = 0 , copy = 0 , i = 0;
	while(i == 0){
		printf("Enter a number (3, 4, or 5) : ");
		scanf("%d",&number);
		copy = number;
		while(number > 0){ 
			number = number / 10;
			digit++;  
		}
		if(digit < 3 || digit > 5){
			printf("Your input must be 3, 4 or 5 digit\n");
			digit = 0;
			copy = 0;
		}
		else{
		while(copy > 0){ 
			reversed = copy % 10;
			printf("%d",reversed);
			copy = copy / 10;
			
		}
		printf("\n");
		return 0;
		}
        }
	return 0;
}
